AssessmentTrainSet:Answer
QUERY_WDID_NEW: long query
QUERY_WDID_NEW_middle: short query
SPLIT_DOC_WDID_NEW: text documents
Spoken_Doc: Spoken documents (ASR Results)
Train: training query (query & documents)

