rm -rf data
rm -rf exp
rm -rf local/__pycache__
rm -rf ../Tools/__pycache__
rm -rf local/*.pyc
rm -rf ../Tools/*.pyc
